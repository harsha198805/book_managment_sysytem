<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                              <div class="d-flex justify-content-between" >
                        <div>View Book </div>
                          <div><a href="<?php echo e(route('books.index')); ?>" class="btn btn-success">Back</a></div>
                    </div>
                </div>

                <div class="card-body">

 <table class="table table-striped">
    <thead>
      <tr>
        <th width="20%">Field Name</th>
        <th width="80%"> Value</th>
     
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Id</td>
        <td><?php echo e($post->id); ?></td>
      
      </tr>
      <tr>
        <td>Book Name</td>
        <td><?php echo e($post->title); ?></td>
      
      </tr>
      <tr>
        <td>Author Name</td>
        <td><?php echo e($post->author_name); ?></td>
      
      </tr>
      <tr>
        <td>Description</td>
        <td><?php echo e($post->description); ?></td>
      
      </tr>
     <tr>
        <td>Category</td>
        <td><?php echo e($post->category->name); ?></td>
      
      </tr>

      <tr>
        <td>tags</td>
        <td>
            <?php if(count($post->tags)): ?>
              <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php echo e($tag->name); ?> <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </td>
      
      </tr>

      <tr>
        <td>Image</td>
        <td>
            <img width="100px" height="100px" src="<?php echo e(asset('post_images/'.$post->image)); ?>">
        </td>
      
      </tr>

      <tr>
        <td>Created At</td>
        <td>
          <?php echo e($post->created_at); ?>

        </td>
      
      </tr>

    </tbody>
  </table>
        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud-master\resources\views/post/show.blade.php ENDPATH**/ ?>